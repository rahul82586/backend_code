# 🔍 MT5 Gap Analysis — What We Have vs What Is Missing
> Based on: `MT5-Administrator/` + `MetaTrader5SDK/` documentation  
> Date: 2026-08-19

---

## 1. Answer: Why Was B-Book Excluded from the Architecture Diagram?

It wasn't excluded — it was just mislabeled. What the diagram calls the **"main_server"** box IS the B-book engine. Here is what the B-book actually consists of internally, which was not shown explicitly:

```
main_server (:8000)  ← This IS the B-book engine
│
├── Matching Engine      ← Holds in-memory Bid/Ask per symbol (the internal book)
├── Trade Center (OMS)   ← Receives orders, locks per-account, routes, fills
│    ├── B-book fill     ← match_order() against internal quotes → deal written
│    └── A-book fill     ← TO_GATEWAY → forwards to LP, deal written on fill
├── Position Keeper      ← Netting engine (hedging or netting mode)
├── RMS Engine           ← Pre-trade margin check, post-fill equity recalc
├── Tick Center          ← On each tick: SL/TP scan, Stop Out scan, P&L update
└── Routing Engine       ← Rules table → decides B-book / Dealer / A-book / Reject
```

So the correct full diagram is:

```
Client Order
     │
     ▼
[Access Server] — auth, rate limit
     │
     ▼
[Trade Center - OMS]
     │
     ├──► [Routing Engine] ─► TO_DEALER → Dealer queue (manual confirm)
     │                  └──► REJECT → order rejected
     │                  └──► TO_GATEWAY → [MT5 Gateway] → LP
     │                  └──► EXECUTE (B-book):
     │                           │
     │                    [RMS - Pre-trade check]
     │                           │ margin OK?
     │                    [Matching Engine] ← fill at internal Bid/Ask
     │                           │
     │                    [Deal Writer] → deals table
     │                    [Position Keeper] → positions table (net/hedge)
     │                    [RMS - Post-fill recalc] → accounts table
     │
     ▼
[Tick Center] — per tick: SL/TP check, pending activation, Stop Out scan
     │
     └──► [Tick Publisher] ──► [History Server] ──► OHLCV bars
```

---

## 2. What We Have Built (Implemented ✅)

| Category | Feature | Status |
|----------|---------|--------|
| **OMS** | Market order placement (BUY/SELL) | ✅ |
| **OMS** | Pending orders (BUY_LIMIT, SELL_LIMIT, BUY_STOP, SELL_STOP) | ✅ |
| **OMS** | Per-account order serialization (asyncio.Lock) | ✅ |
| **OMS** | Order state machine (STARTED → FILLED / REJECTED) | ✅ |
| **OMS** | Stale quote gating (rejects market orders if quote >10s old) | ✅ |
| **Matching** | In-memory Bid/Ask price book per symbol | ✅ |
| **Matching** | B-book fill at top-of-book spread | ✅ |
| **Matching** | Quote age tracking + `get_quote_age()` | ✅ |
| **Position** | Netting mode positions (same symbol merges) | ✅ |
| **Position** | Position close by opposing order | ✅ |
| **Position** | Partial close / reverse | ✅ |
| **Position** | In-memory cache with DB sync | ✅ |
| **RMS** | Pre-trade margin check (free margin) | ✅ |
| **RMS** | Post-fill equity/margin recalculation | ✅ |
| **RMS** | Stop Out detection and liquidation trigger | ✅ |
| **RMS** | Group-symbol margin override (group_symbols table) | ✅ |
| **RMS** | Stale quote Stop Out pause (skips accounts with stale positions) | ✅ |
| **Routing** | Priority-ordered routing rules engine | ✅ |
| **Routing** | Match by group, symbol, order type, volume range | ✅ |
| **Routing** | Actions: EXECUTE / TO_DEALER / TO_GATEWAY / REJECT | ✅ |
| **Routing** | Server default fallback | ✅ |
| **Tick Center** | SL trigger detection on tick | ✅ |
| **Tick Center** | TP trigger detection on tick | ✅ |
| **Tick Center** | Pending order activation on tick | ✅ |
| **Tick Center** | Floating P&L update on tick | ✅ |
| **Deals** | Deal record writing (ticket, login, action, entry, price, profit) | ✅ |
| **Schema** | accounts, groups, symbols, orders, positions, deals | ✅ |
| **Schema** | routing_rules, group_symbols tables | ✅ |
| **Schema** | PostgreSQL + SQLite dual-mode | ✅ |
| **Access Server** | Reverse proxy with auth validation | ✅ |
| **Access Server** | Rate limiting per IP | ✅ |
| **Access Server** | Regional upstream routing | ✅ |
| **Access Server** | WebSocket transparent upgrade | ✅ |
| **Access Server** | Path-prefix routing (/history/* → port 8002) | ✅ |
| **History Server** | OHLCV bar aggregation (1m/5m/1h/1d) | ✅ |
| **History Server** | Chart history API GET /history/{symbol} | ✅ |
| **History Server** | Fire-and-forget tick publisher (bounded queue, backpressure) | ✅ |
| **LP / A-book** | MT5 price feed via trade-server WebSocket | ✅ |
| **LP / A-book** | Quote filtration (spread, price jump) | ✅ |
| **LP / A-book** | A-book order execution via trade-server | ✅ |
| **LP / A-book** | Gateway failure isolation (no B-book fallback) | ✅ |
| **Admin** | Account CRUD | ✅ |
| **Admin** | Group CRUD | ✅ |
| **Admin** | Symbol CRUD | ✅ |
| **Admin** | Routing rule CRUD | ✅ |
| **Security** | Session management (Redis + in-memory fallback) | ✅ |
| **Security** | Internal shared secret (X-Internal-Secret) | ✅ |
| **Security** | Defense-in-depth double token validation | ✅ |

---

## 3. What Is Missing — Gap Analysis

### 🔴 CRITICAL GAPS (Core MT5 behavior, required for a real broker)

| # | Missing Feature | MT5 SDK Reference | Impact |
|---|----------------|-------------------|--------|
| 1 | **Swap / Rollover calculation** | `IMTConSymbol::SwapLong/Short/Mode`, `IMTDeal::Storage` | Without daily swap, positions held overnight accumulate incorrect P&L. Deals currently have `storage=0.0` always. |
| 2 | **Commission calculation** | `IMTConGroup::CommissionAdd`, `IMTDeal::Commission` | All deals have `commission=0`. Real brokers charge per-lot or per-deal commissions. Commission must be added to deal records and deducted from balance. |
| 3 | **Hedging position mode** | `IMTConGroup::TradeFlags::TRADE_FLAGS_HEDGE` | Currently only netting mode is implemented. Hedging mode allows multiple positions per symbol (MT5 default for retail). |
| 4 | **Trading sessions / market hours** | `IMTConSymbol::SessionQuote*`, `SessionTrade*` | Currently orders are accepted 24/7. MT5 checks if current time is within the symbol's defined quoting and trading sessions, and rejects orders outside them. |
| 5 | **Holiday calendar** | `IMTConHoliday` (Config-Interfaces/Holidays) | No holiday enforcement. Orders must be rejected on market holidays. |
| 6 | **Stop Out liquidation logic** | `IMTAccount::SOActivation`, FIFO rule | Currently we just detect Stop Out and log. We don't actually automatically close the largest-loss position or cancel the largest-margin pending order. The full Stop Out sequence (find worst position → place close request → set SOActivation) is missing. |
| 7 | **Order volume limits per symbol** | `IMTConSymbol::VolumeMin/Max/Step` | No validation that submitted volume is within the symbol's allowed min/max/step range. |
| 8 | **StopsLevel / FreezeLevel** | `IMTConSymbol::StopsLevel`, `FreezeLevel` | No check that SL/TP prices are at least StopsLevel points away from current price. No freeze level enforcement on modification. |
| 9 | **Order modification (SL/TP change)** | `PUT /trade/order/{ticket}` | No endpoint to modify an existing order's SL, TP, or price. |
| 10 | **Order cancellation** | `DELETE /trade/order/{ticket}` | No endpoint to cancel a pending order. |
| 11 | **Balance operations (deposit/withdrawal)** | `IMTDeal::DEAL_BALANCE`, `DEAL_CREDIT`, `DEAL_BONUS` | No deposit/withdrawal transaction endpoints. Balance can only change from trade fills. |
| 12 | **Daily EOD reports** | `IMTConGroupSink`, `Interface-of-End-of-Day-Events` | No end-of-day processing: balance snapshots, daily P&L reports, daily commission/swap settlement. |

---

### 🟠 IMPORTANT GAPS (Needed for production quality)

| # | Missing Feature | MT5 SDK Reference | Impact |
|---|----------------|-------------------|--------|
| 13 | **Depth of Market (DOM)** | `MTBookItem`, `MTBookMTBookDiff`, `IMTConSymbol::TickBookDepth` | No order book / Level 2 data. MT5 clients can view DOM. |
| 14 | **Tick statistics** | `MTTickStat` (Structures) | No per-symbol tick statistics tracking (bid/ask counts, spread history, etc.). |
| 15 | **Summary (aggregate) positions** | `IMTSummary`, `IMTSummaryArray` (Trade/Summary-Positions) | No broker-level aggregate position view (total net long vs short per symbol across all clients). Essential for B-book risk management. |
| 16 | **Manager / Dealer accounts** | `IMTConManager` (Configuration-Interfaces/Managers) | No concept of manager or dealer users. All admin is done via a single service-level account. MT5 has role-based manager accounts with scoped permissions. |
| 17 | **Dealer workflow** | `Manager-API/Dealer-Interface`, `DealerAnswer` | Orders routing to `TO_DEALER` are placed in a queue but no actual dealer UI or confirmation workflow is implemented. |
| 18 | **Margin call notification** | `IMTConGroup::MarginCall` | Margin call level is stored but no notification is sent to the client when equity drops to margin call level (before stop out). |
| 19 | **Slippage / requote** | `IMTConSymbol::IESlipProfit/IESlipLosing`, `MT_RET_REQUEST_REQUOTE` | No instant execution slippage model. Currently fills are always at the exact requested price (or top-of-book). |
| 20 | **Price limits** | `IMTConSymbol::PriceLimitMax/PriceLimitMin` | No maximum/minimum price boundary enforcement on orders. |
| 21 | **Account limits** | `IMTConGroup::LimitOrders`, `LimitPositions`, `LimitSymbols` | No per-account limits on number of simultaneous open orders, positions, or quoted symbols. |
| 22 | **Credit / virtual credit** | `IMTConGroup::TradeVirtualCredit` | No credit (bonus) balance support. All accounts have pure cash balance only. |
| 23 | **Interest rate** | `IMTConGroup::TradeInterestrate` | No annual interest calculation on positive balances. |
| 24 | **Symbol path hierarchy** | `IMTConSymbol::Path` | Symbols are flat. MT5 organizes symbols into category trees (e.g. `Forex\EURUSD`, `Crypto\BTCUSD`). |
| 25 | **Subscription quota** | `IMTConGroup::LimitSymbols` | No limit on how many symbols a client WebSocket can simultaneously subscribe to. |
| 26 | **Startup order cleanup** | `Request-Processing-on-the-Server.md §Removing-unprocessed-orders` | On server restart, STARTED state orders should be canceled/reset. Currently they can freeze in STARTED state. |
| 27 | **External order ID** | `IMTOrder::ExternalID`, `IMTExecution::OrderExternalID` | A-book orders filled by LP don't store the LP's external order ID. MT5 requires this to prevent the server from removing gateway-placed orders on restart. |

---

### 🟡 SCHEMA GAPS (Tables / Columns Missing)

| Table | Missing Columns | MT5 Reference |
|-------|----------------|---------------|
| `symbols` | `swap_long`, `swap_short`, `swap_mode`, `swap_year_days` | `IMTConSymbol::SwapLong/Short/Mode/YearDays` |
| `symbols` | `volume_min`, `volume_max`, `volume_step` | `IMTConSymbol::VolumeMin/Max/Step` |
| `symbols` | `stops_level`, `freeze_level` | `IMTConSymbol::StopsLevel/FreezeLevel` |
| `symbols` | `price_limit_min`, `price_limit_max` | `IMTConSymbol::PriceLimitMin/Max` |
| `symbols` | `exec_mode` (INSTANT/REQUEST/MARKET/EXCHANGE) | `IMTConSymbol::ExecMode` |
| `symbols` | `calc_mode` (FOREX/CFD/FUTURES etc.) | `IMTConSymbol::CalcMode` |
| `symbols` | `session_quotes`, `session_trades` (JSON or separate table) | `IMTConSymbol::SessionQuote*/SessionTrade*` |
| `symbols` | `trade_mode` (DISABLED/LONGONLY/SHORTONLY/FULL) | `IMTConSymbol::TradeMode` |
| `groups` | `currency`, `currency_digits` | `IMTConGroup::Currency/CurrencyDigits` |
| `groups` | `trade_flags` (hedge/FIFO/etc.) | `IMTConGroup::TradeFlags` |
| `groups` | `margin_free_mode`, `margin_so_mode` | `IMTConGroup::MarginFreeMode/MarginSOMode` |
| `groups` | `limit_orders`, `limit_positions`, `limit_symbols` | `IMTConGroup::LimitOrders/Positions/Symbols` |
| `groups` | `trade_virtual_credit`, `trade_interestrate` | `IMTConGroup::TradeVirtualCredit/Interestrate` |
| `groups` | `demo_leverage`, `demo_deposit` | `IMTConGroup::DemoLeverage/Deposit` |
| `accounts` | `credit` (bonus balance) | `IMTUser::Credit` |
| `accounts` | `agent_account`, `country`, `client_id` | `IMTUser` client profile fields |
| `accounts` | `registration` (timestamp), `last_access` | `IMTUser::Registration/LastAccess` |
| `deals` | `commission` | `IMTDeal::Commission` |
| `deals` | `storage` (swap charged on this deal) | `IMTDeal::Storage` |
| `deals` | `price_position` (close price of position) | `IMTDeal::PricePosition` |
| `deals` | `profit_raw` (profit in symbol currency before conversion) | `IMTDeal::ProfitRaw` |
| `deals` | `rate_profit`, `rate_margin` | `IMTDeal::RateProfit/RateMargin` |
| `deals` | `external_id` (LP order ID) | `IMTDeal::ExternalID` |
| `deals` | `dealer` (who processed the deal) | `IMTDeal::Dealer` |
| `orders` | `price_current` (last market price of pending order) | `IMTOrder::PriceCurrent` |
| `orders` | `price_trigger` (stop-limit trigger price) | `IMTOrder::PriceTrigger` |
| `orders` | `external_id` | `IMTOrder::ExternalID` |
| `orders` | `expert_id` (EA magic number) | `IMTOrder::ExpertID` |
| `orders` | `volume_current` (remaining volume after partial fill) | `IMTOrder::VolumeCurrent` |
| `positions` | `swap` (accumulated swap balance) | `IMTPosition::Storage` |
| `positions` | `commission` | `IMTPosition::Commission` |
| `positions` | `price_current` | `IMTPosition::PriceCurrent` |
| `positions` | `external_id` | `IMTPosition::ExternalID` |
| **NEW** | `holidays` table | `IMTConHoliday` |
| **NEW** | `managers` table | `IMTConManager` |
| **NEW** | `commissions` table (per-group commission tiers) | `IMTConCommission/IMTConCommTier` |
| **NEW** | `daily_reports` table | End-of-Day events |
| **NEW** | `summary_positions` view/table | `IMTSummary` |

---

### 🔵 ENTIRE SUBSYSTEMS NOT STARTED

| Subsystem | What It Does | MT5 SDK Reference |
|-----------|-------------|-------------------|
| **Backup Server** | Hot standby — replicates all data; switches automatically on primary failure | `Platform-Components/Backup-Server` |
| **Data Feed subsystem** | Full tick feed management: multiple feed sources, failover, filtering config per-symbol | `Configuration-Interfaces/Data-Feeds` |
| **Spreads management** | Dynamic spread profiles per group — can widen during news, off-hours | `Configuration-Interfaces/Spreads` |
| **Plugin API** | Server-side plugins (C++ DLL hooks into request/execution pipeline via OnTradeRequest hooks) | `Server-API` (entire section) |
| **Report API** | Automated PDF/HTML trade reports, account statements | `Report-API/` |
| **Web API / WebTerminal** | Browser-based terminal with REST+WebSocket API separate from Manager API | `Web-API/`, `Platform-Components/WebTerminal` |
| **Geo Services** | IP geolocation for client routing and compliance | `Database-Interfaces/Geo-Services` |
| **KYC** | Know-Your-Customer document verification integration | `Configuration-Interfaces/KYC` |
| **Automations** | Server-side scheduled automations (interest accrual, daily cleanups) | `Configuration-Interfaces/Automations` |
| **VPS** | Virtual Private Server hosting for EA strategies | `Configuration-Interfaces/VPS` |
| **News / Mailbox** | Internal news broadcast to client terminals, mailbox messaging | `IMTConGroup::NewsMode/MailMode` |
| **ECN** | Electronic Communication Network integration (visible order book from multiple LPs) | `Database-Interfaces/ECN` |
| **Floating Margin Profiles** | Dynamic margin based on position size tiers | `Configuration-Interfaces/Floating-Margin` |
| **Funds & ETF** | Special instrument types with NAV-based pricing | `Configuration-Interfaces/Funds-and-ETF` |
| **Network Cluster** | Multi-server cluster with load balancing and failover | `Platform-Setup/Network-cluster` |
| **Certificates** | SSL certificate management for client connections | `Database-Interfaces/Certificates` |
| **Subscriptions** | Per-client symbol subscription management (delayed quotes, premium data) | `Configuration-Interfaces/Subscriptions` |
| **Online Connections** | Real-time connected client session tracking | `Database-Interfaces/Online-Connections` |

---

## 4. Implementation Priority Recommendations

### Phase 8 — Minimum Viable Broker (P0)
These gaps make the system incorrect for even a demo broker:

1. **Stop Out auto-liquidation** — actually close the worst-loss position, set SOActivation
2. **Commission calculation** — deduct from balance on every deal fill
3. **Swap/rollover** — charge nightly on held positions
4. **Order cancel / modify endpoints** — `DELETE /trade/order/{ticket}`, `PUT /trade/order/{ticket}`
5. **Volume validation** — min/max/step per symbol
6. **Startup STARTED order cleanup**

### Phase 9 — Production Readiness (P1)

7. **Balance operations** — deposit/withdrawal endpoints with deal type DEAL_BALANCE
8. **Trading sessions** — reject orders outside configured market hours
9. **Holiday calendar** — reject orders on holidays
10. **Hedging position mode** — parallel positions per symbol
11. **Margin call notification** — alert client when equity hits margin call level
12. **StopsLevel enforcement** — reject SL/TP too close to current price

### Phase 10 — Advanced Features (P2)

13. **Summary positions** — broker-level net exposure view
14. **Manager / Dealer accounts** — role-based access with permission flags
15. **Dealer confirmation workflow** — full dealer queue UI + confirm/reject flow
16. **Dynamic spreads** — spread groups per time / news event
17. **Commission tiers** — volume-based commission tiers per group
18. **Report generation** — daily account statements

---

## 5. Summary

| Category | Total MT5 Features | Currently Implemented | Missing |
|----------|-------------------|----------------------|---------|
| Order lifecycle | ~15 | 8 | 7 |
| Position management | ~10 | 5 | 5 |
| Risk management (RMS) | ~12 | 6 | 6 |
| Schema fields | ~80 | ~35 | ~45 |
| Configuration (symbols/groups) | ~60 attributes | ~15 | ~45 |
| Subsystems (major) | ~18 | 5 (access/main/history/trade-server/gateway) | 13 |
| Admin / management | ~20 | 6 | 14 |

**Current completion estimate: ~35-40% of a full MT5-equivalent broker server.**  
The foundation is solid and architecturally correct. The core order → deal → position pipeline is properly implemented. What's missing is primarily the financial math layers (swap, commission, sessions) and broker management systems (reports, dealer workflow, summary risk).
