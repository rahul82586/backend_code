# Enterprise Broker Server: Full System Capabilities & Architecture Report

This report presents a comprehensive overview of the entire Broker Server system (Phases 1, 2, and 3). It details the architectural blocks, the functional capabilities of the current implementation, and deployment models.

---

## 1. System Architecture Overview

The platform uses a decoupled, high-performance architecture built in Python, using `FastAPI` (with `uvloop` for high-throughput ASGI performance), `asyncpg` / `aiosqlite` for database connectivity, and `Redis` for caching, rate limiting, and session management.

```mermaid
graph TD
    %% Clients
    C1[Retail Trader Client] -->|HTTP / WebSockets| Edge[Edge Access Proxy: Port 8080]
    C2[Admin / Manager Dashboard] -->|HTTP / REST| Edge

    %% Access Edge
    subgraph Access Edge Proxy [Edge Boundary]
        Edge --> FW[IP Firewall: Allow/Deny List]
        Edge --> RL[Sliding Window Rate Limiter]
        Edge --> VR[Session Validation Reader]
    end

    %% Central Cache
    subgraph Central Cache [State & Session Caching]
        VR -->|Fast Check| RD[(Shared Redis Cluster)]
        RL -->|Sync Hits| RD
    end

    %% Internal Boundary
    Edge -->|HTTP Proxy / X-Internal-Secret| Internal[Internal Boundary]
    
    %% Core Main Server
    subgraph Core Trading Server [Main Server: Port 8000]
        Internal --> WebAPI[FastAPI Web API]
        WebAPI --> EB[In-Memory Event Bus]
        
        subgraph Trading Engine Core [Order Execution Core]
            TC[Trade Center] --> ME[Matching Engine: LOB & priority queue]
            TC --> RMS[Risk Management Engine: Margin, Stops, Stop-out]
            TC --> PK[Position Keeper: floating PnL tracker]
            TC --> TC_Start[Startup Order Cleanup]
        end
        
        subgraph Tick & Feed System
            TickF[Tick Center] --> PK
            TickF --> TC
        end
    end

    %% Databases
    subgraph Persistent Storage
        WebAPI --> DB[(SQL Database: Postgres / Sqlite fallback)]
        RMS --> DB
    end

    classDef edgeClass fill:#0d233a,stroke:#1f538d,stroke-width:2px,color:#fff;
    classDef coreClass fill:#1b3d54,stroke:#3b82b6,stroke-width:2px,color:#fff;
    classDef storageClass fill:#14221f,stroke:#2a5c4e,stroke-width:2px,color:#fff;
    class Edge,FW,RL,VR edgeClass;
    class WebAPI,TC,ME,RMS,PK,EB,TickF coreClass;
    class RD,DB storageClass;
```

---

## 2. Completed Capabilities (Phase by Phase)

### Phase 1: Core Broker Server Foundation & Matching Engine
- **Advanced Matching Engine (`matching/engine.py`):**
  - **Market Orders:** Immediate matching against top-of-book liquidity.
  - **Limit Orders:** Standard Limit Order Book (LOB) with price-time priority queues.
  - **Stop Orders:** Triggered when the market bid/ask crosses the stop price, automatically upgrading to market orders.
  - **Order Cancellations:** Instantly purges pending orders from the LOB priority queues.
- **Enterprise Risk Management System (RMS) Engine (`rms/engine.py`):**
  - **Real-Time Margin Calculations:** Calculates leverage constraints, used margin, free margin, and margin level.
  - **Dynamic Leverage Support:** Inherited from account group configurations.
  - **Margin Call Warning:** Logs alerts if the margin level dips below warning levels.
- **Hybrid Database Connection Engine:**
  - Standard PostgreSQL (`asyncpg`) database driver.
  - Automatic fallback to a local developer SQLite (`aiosqlite`) database connection when PostgreSQL is unreachable, displaying a developer warning banner at startup.

### Phase 2: Tick Processing, SL/TP, and Stop-Outs
- **Asynchronous Tick Center (`core/tick_center.py`):**
  - Processes bid/ask price feeds.
  - Automatically updates the floating PnL (profit & loss) and equity calculations for all open positions in real-time.
- **Automated SL/TP Checks:**
  - Evaluates Stop Loss (SL) and Take Profit (TP) targets for open positions on every price tick.
  - Automatically triggers market order exits when price levels are breached.
- **Automated Stop-Out Execution:**
  - Triggers stop-outs when account margin levels fall below the group stop-out threshold (e.g., 30%).
  - Automatically initiates liquidation of positions, starting with the **largest losing position first**, until the account's margin level rises back above the stop-out threshold.
- **Real-Time Event Bus (`shared/event_bus.py`):**
  - Publishes real-time symbol price ticks, order fills, stop-outs, and balance updates to connected subscribers.

### Phase 3: Standalone Access Server Edge & Security Boundary
- **Standalone Access Server Proxy (`access_main.py`):**
  - Proxies HTTP requests and upgrades WebSocket streams to the main trading servers.
  - Handles IP Allow/Deny Firewall rules.
  - Implements sliding-window rate limiting on IPs and account logins.
- **High-Availability Session Manager (`SessionManager`):**
  - Centralized Redis session caching.
  - **Dual-Write Hot Standby:** Sessions are written to both Redis and a local in-memory fallback.
  - **Auto-Healing Circuit Breaker:** Bypasses Redis instantly on failure and retries every 10 seconds, recovering automatically from transient Redis blips.
- **Enterprise-Grade Security:**
  - Password hashing via **salted PBKDF2-HMAC-SHA256 with 600,000 iterations** and CSPRNG salts.
  - Timing-attack-safe validation checks via `secrets.compare_digest`.
  - Secure `X-Internal-Secret` header validation gating the internal validation endpoint.

---

## 3. What is Possible with the Current Implementation

The current codebase is ready to be compiled, containerized, or deployed as a distributed trading system. Here is what you can do with it:

### A. Run a Fully-Functional Multi-Asset Brokerage (Simulated Feed)
You can deploy this codebase to operate a brokerage backend where:
1. Traders register, authenticate securely (timing-safe PBKDF2), deposit funds, and open accounts.
2. Traders open the web dashboard or API to submit orders (Market, Limit, Stop).
3. The system processes a simulated feed of price ticks. The Position Keeper tracks positions, recalculates free margin, and closes trades instantly if Stop Loss, Take Profit, or Stop-Out levels are hit.

### B. Distributed Global Deployment (Edge Computing)
You can compile these servers into standalone executables or containerize them into Docker containers:
- **Global Edge Proxies:** Deploy multiple lightweight `access_server` containers at the cloud edge (e.g., AWS regions close to London, New York, Tokyo). They handle heavy tasks like SSL termination, IP rate limiting, firewall checks, and session verification.
- **Central Core Servers:** Deploy the core `main_server` in a secure private network. The internal endpoints are isolated and reachable only by proxies presenting the correct `X-Internal-Secret` token.

### C. Live Real-Time WebSockets Streaming
Traders can connect to the public Access Server proxy WebSockets stream:
- `ws://<proxy_ip>:8080/ws/stream/{account_id}?token={token}`
- The proxy validates the token and channels real-time tick price updates and position mutations directly to the trader's web interface without polling delays.

---

## 4. Local Execution Commands

### Execution & Testing

* **Verify the Entire Stack (Integration Suite):**
  This runs all matching engine tests, Stop Loss/Take Profit checks, stop-out liqudation logic, rate limiting, and WebSocket proxying tests in-memory:
  ```powershell
  cd broker_server/main_server
  python -m pytest tests/test_phase3.py tests/test_phase2_ticks.py
  ```

### Local Dev Startup (Processes)

* **Start the Core Main Server:**
  ```powershell
  cd broker_server/main_server
  python main.py
  ```

* **Start the Access Edge Proxy:**
  ```powershell
  cd broker_server/access_server
  uvicorn access_main:app --port 8080
  ```
