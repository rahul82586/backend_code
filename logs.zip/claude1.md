# Fix Phase-1 broker_server bugs + verify against MT5 reference material

## Context
`broker_server/main_server` is a Phase-1 scaffold (Python monolith, FastAPI + asyncpg/SQLite fallback) implementing OMS/RMS/Matching/PositionKeeper with a clean interface layer. Tests pass (`pytest`, 2/2) but that only proves the happy path on SQLite. A review surfaced 3 reproduced bugs and 2 structural issues that all involve money/position correctness. Fix these before any new Phase-2 work (price feed, gateway, etc.).

## Reference material available locally — use it to verify correct behavior, not just to make tests pass
- `C:\Users\DELL\Downloads\server3\1MT5` — real MT5 server-side files (access/trade/history/backup). Use this to check actual state-transition and locking behavior for order/position handling, not just the doc summaries.
- `C:\Users\DELL\Downloads\server3\mt5_doc_dump\Documentation\MQ_Docs\Metatrader 5\MetaTrader5SDK` — official SDK docs + code examples. Check specifically: `Request-Processing-on-the-Server.md` (order state machine, hook sequence), `Trade/Margin-Calculation/`, `Trade/Profit-Calculation.md`, `Groups/Position-Accounting-Systems.md` (netting vs hedging).
- `C:\Users\DELL\Downloads\server3\MT5-Administrator` — admin-side docs, useful for stop-out/margin-call operational behavior and group config semantics.
- `C:\Users\DELL\Downloads\server3\theia-master` — architecture/plugin-pattern reference only (not runtime code to import).
- `C:\Users\DELL\Downloads\server3\bridge_manual_md` — Centroid bridge docs, useful for gateway/fill-reporting conventions later (Phase 3), not needed for this fix pass.

Where a fix touches order/position/margin logic, cross-check the exact sequencing against the MT5 SDK docs above and note in a code comment which doc section it matches (e.g. `# per Request-Processing-on-the-Server.md step 4f`).

## Bugs to fix

### 1. Crash on close with no existing position (confirmed via repro script)
`core/position_keeper.py`, `update_position()`: when `deal_entry == 1` (ENTRY_OUT) and no existing position is found, the method logs a warning and falls through to `return self._positions.get(ticket, {})` — `ticket` is never assigned on that path, raising `UnboundLocalError`.
**Fix:** handle this as an explicit error path (raise a typed exception, e.g. `PositionNotFoundError`) that `TradeCenter` catches and turns into a proper order rejection — don't let it propagate as an unhandled crash. Also audit for the same pattern anywhere else `ticket`/similar locals are set only inside conditional branches.

### 2. Matching engine trusts client-submitted price when no quote exists (confirmed via repro script)
`matching/engine.py`, `match_order()`: if no quote is loaded for the symbol, it fills at the client's `price_request` verbatim. Confirmed exploitable: an order with `price_request=0.00001` fills at `0.00001`.
**Fix:** this must never be reachable once real quotes exist. Either (a) reject the order with a clear `NO_QUOTE_AVAILABLE` error when no quote is set, or (b) if you want a dev-only fallback, gate it behind an explicit `ALLOW_UNQUOTED_FILLS` config flag that defaults to `False` and is loud in logs when active. Do not leave silent "fill at whatever the client asked" as default behavior anywhere close to a real order path.

### 3. No per-account concurrency control → position corruption (confirmed via repro script)
Firing 5 concurrent 1-lot BUY orders for the same login/symbol produced 4 fragmented position rows totaling the right volume (5.0) instead of 1 netted position — a race in `position_keeper.update_position()`'s read-then-write of the existing position row.
**Fix:** serialize order processing per account. Recommended: an `asyncio.Lock` per `login` (dict of locks in `TradeCenter` or `PositionKeeper`, created on first use) held for the full `place_order` → position-update sequence. Longer-term (Postgres): also use `SELECT ... FOR UPDATE` on the position row inside the transaction so the DB itself enforces it, not just the app process — check MT5 SDK `Request-Processing-on-the-Server.md` for how MT5 serializes per-group (they use one thread per group — note this in a comment as the reference behavior). Add a regression test that fires N concurrent orders for one login/symbol and asserts exactly one resulting position row with the correct summed volume and averaged price.

### 4. No atomicity across order → deal → position → account update
`TradeCenter.place_order()`, `DealWriter.write_deal()`, and `PositionKeeper.update_position()` each call `pool.acquire()` independently, each with their own transaction. On real Postgres these are three separate transactions with no atomicity guarantee — a crash mid-sequence can leave a deal written and balance moved with no matching position update. Also: the generic `except Exception` handler in `place_order` marks the order `REJECTED` even if the deal/balance update already committed successfully before the exception — meaning the order's stored status can lie about what happened to the client's money.
**Fix:** wrap the full place_order sequence (order insert → deal write → balance update → position update) in a single transaction on one acquired connection, passed down to `DealWriter` and `PositionKeeper` rather than each acquiring their own. If any step fails, the whole thing rolls back — no partial state. Only mark `REJECTED` for failures that occur *before* the deal is committed; failures after that point need a different code path (e.g. flag for manual reconciliation, since the money already moved) — don't silently relabel a partially-succeeded order as rejected.

### 5. N+1 query pattern reintroduced in rms/engine.py
`recalculate_accounts()` issues a separate `SELECT contract_size FROM symbols WHERE symbol = $1` per position, per account, on every recalculation call — this is the exact anti-pattern the project's own `00-revised-strategy-v2.md` (§7) identifies as the root cause of `server3`'s DB slowness.
**Fix:** batch-fetch all needed symbol rows in one query (`WHERE symbol = ANY($1)`) before the per-position loop, or cache the symbols table in memory (it changes rarely) and invalidate on admin symbol updates.

## Also worth addressing this pass (lower severity, flag if you don't have time)
- `rms/accounting.py` converts Decimal → numpy `float64` → Decimal (via string formatting) for P&L/margin math. This reopens floating-point rounding error in ledger calculations that the rest of the codebase deliberately keeps as exact Decimal. Recommend dropping numpy for this and doing the P&L/margin math in plain Decimal in a simple loop — position counts per account are not large enough for numpy's vectorization to matter, and correctness beats speed here per the project's own `05-risk-management.md` ("Any error here = wrong balance for the client").
- `DBConnection.initialize()` defaults `DB_TYPE` to `"sqlite"` silently. Given "no SQLite in production" is an explicit project principle (`07-database-schema.md` §7.1), make this fail loud instead of silently falling back — e.g. require `DB_TYPE` to be set explicitly, or log a very visible warning banner when running on SQLite.
- No `main.py` entrypoint — currently you have to know to run `uvicorn webapi.manager_api:app`. Add a `main.py` per the layout in `00-revised-strategy-v2.md` §6.
- `check_stop_outs()` only detects and returns breaching logins — it doesn't actually close anything. Fine for now, but make sure this isn't mistaken for "stop-out is implemented" — Phase 2/RMS work still needs to wire the actual liquidation call (largest-losing-position-first, per `05-risk-management.md` §5.5 / MT5 SDK stop-out sequence).

## Requirements for this fix pass
1. Fix items 1–5 above.
2. Add regression tests for each: the crash case, the no-quote fill case, and the concurrency race (the concurrency test is the most important — it should fail on the current code and pass after the fix).
3. Run the full test suite against **both** SQLite and real Postgres if Postgres is available locally — don't rely on SQLite-only passing as proof of correctness, since the query-translation shim (`bases/connection.py`) is not a verified 1:1 stand-in for asyncpg behavior.
4. Where you touch order/position/margin sequencing, add a short comment citing the specific MT5 SDK doc section you checked against.
5. Report back: what changed per file, and which of the "lower severity" items above you also addressed vs. deferred.