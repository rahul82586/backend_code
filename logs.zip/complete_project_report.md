# 📋 Broker Server — Complete Project Report
> **From first folder to Phase 7 MT5 Integration**  
> Generated: 2026-08-19

---

## 🗂️ Table of Contents
1. [Project Overview](#1-project-overview)
2. [Architecture Diagram](#2-architecture-diagram)
3. [Phase-by-Phase Changelog](#3-phase-by-phase-changelog)
4. [Complete File Reference Table](#4-complete-file-reference-table)
5. [Test Suite Summary](#5-test-suite-summary)
6. [Final Test Results — 29/29 Passed](#6-final-test-results)

---

## 1. Project Overview

This project builds a **professional-grade, multi-process broker trading server** modeled on MT5 server architecture. It consists of three independent FastAPI microservices and one external LP connector:

| Service | Port | Purpose |
|---------|------|---------|
| `access_server` | 8001 | Reverse proxy, authentication gate, WebSocket upgrader |
| `main_server` | 8000 | Core OMS/RMS/Matching engine, trade execution |
| `history_server` | 8002 | OHLCV bar aggregation, chart history API, LP gateway bridge |
| `trade-server` | 8003 | MT5 terminal connector (external LP / price feed) |

---

## 2. Architecture Diagram

```
                        ┌─────────────────────────────┐
   Client ──────────►   │     access_server (:8001)    │  ← Auth, proxy, WebSocket
                        └────────────┬────────────────┘
                                     │ Routes by path/region
                        ┌────────────▼────────────────┐
                        │     main_server (:8000)      │  ← OMS, RMS, Matching
                        │  ┌──────────────────────┐   │
                        │  │  Matching Engine      │   │
                        │  │  Trade Center (OMS)   │   │
                        │  │  RMS Engine           │   │
                        │  │  Position Keeper      │   │
                        │  │  Tick Center          │   │
                        │  │  Routing Engine       │   │
                        │  └──────────────────────┘   │
                        └──────┬──────────────┬───────┘
                               │              │
               Fire-and-forget │      A-Book  │ execution
               tick publish    │      routing │ (REAL_LP)
                        ┌──────▼──────────────▼───────┐
                        │   history_server (:8002)     │  ← Bar aggregation, LP bridge
                        │  ┌──────────────────────┐   │
                        │  │  Bar Aggregator       │   │
                        │  │  MT5 Feed (Datafeeds) │   │
                        │  │  MT5 Gateway          │   │
                        │  └──────────────────────┘   │
                        └────────────┬────────────────┘
                                     │ WebSocket ticks + HTTP orders
                        ┌────────────▼────────────────┐
                        │   trade-server (:8003)       │  ← MT5 terminal connector
                        │  (python-MetaTrader5)        │
                        └─────────────────────────────┘
```

---

## 3. Phase-by-Phase Changelog

### Phase 1 — Project Bootstrap & Folder Structure
- Created root workspace at `C:\Users\DELL\Downloads\server3\`
- Created three service directories: `broker_server/main_server/`, `broker_server/history_server/`, `broker_server/access_server/`
- Set up `requirements.txt` for each service
- Designed PostgreSQL schema (`bases/schema.sql`) for all core tables: `accounts`, `groups`, `symbols`, `orders`, `positions`, `deals`, `routing_rules`, `group_symbols`
- Created SQLite fallback schema (`bases/schema_sqlite.sql`) for developer testing
- Implemented `bases/connection.py` — dual-mode DB adapter (PostgreSQL or SQLite with async wrapper)

---

### Phase 2 — Core OMS & Matching Engine
- Implemented `matching/engine.py` — in-process price book holding current Bid/Ask quotes per symbol
- Implemented `core/trade_center.py` — Order Management System: validates, locks per-account, routes, executes, logs all trade orders
- Implemented `core/position_keeper.py` — in-memory position cache synchronized to the database; handles netting
- Implemented `core/deal_writer.py` — writes deal records atomically within existing DB transactions
- Implemented `core/tick_center.py` — processes ticks, evaluates SL/TP, updates floating P&L, triggers Stop Out checks
- Implemented `shared/schemas/v1.py` — shared constants for order states, reasons, entries, and types
- Implemented `shared/event_bus.py` — in-process async pub/sub event bus
- Implemented `core/interfaces/` — abstract base classes (IOMS, IRMS, IMatching, IPositionKeeper, IEventBus)
- Wrote and passed `tests/test_trade.py` and `tests/test_phase2_ticks.py`

---

### Phase 3 — Access Server & Security
- Built `access_server/access_main.py` — full reverse proxy with JWT/session auth, rate limiting, regional routing, WebSocket upgrade
- Created `access_server/config/access.ini` — region-server mapping configuration
- Implemented `/internal/auth/validate` on `main_server` for double-validation (defense-in-depth)
- Implemented `webapi/manager_api.py` — main FastAPI app with: session management (Redis + in-memory fallback), `POST /auth/login`, `POST /trade/order`, admin CRUD routes
- Wrote and passed `tests/test_phase3.py`

---

### Phase 4 — Admin Routing Engine & Group Margins
- Implemented `routing/engine.py` — priority-ordered routing rules engine matching on group, symbol, order type, volume range; returns EXECUTE / TO_DEALER / TO_GATEWAY / REJECT; falls back to server default
- Implemented `rms/accounting.py` — margin calculation with group-symbol overrides; uses Decimal math
- Enhanced `rms/engine.py` — pre-trade margin check, post-fill account recalculation, `check_stop_outs()`
- Added admin routes: `POST/GET /admin/routing`, `DELETE /admin/routing/{id}`, `POST /admin/groups`, `POST/GET /admin/symbols`
- Wrote and passed `tests/test_phase4.py`

---

### Phase 5 — Bug Fixes & Regression Hardening
- Fixed crash on close of non-existent position (`ValueError("Position not found")` instead of `UnboundLocalError`)
- Added `ALLOW_UNQUOTED_FILLS` env var — controls rejection of orders with no live quote
- Fixed concurrent order race condition via per-account `asyncio.Lock()` — concurrent orders net correctly
- Wrote and passed `tests/test_bugs.py` and `tests/test_margin.py`

---

### Phase 6 — History Server & Decoupled Tick Recording
- Created `history_server/history_main.py` — independent FastAPI app on port 8002 with tick ingest WebSocket, OHLCV chart history endpoint, independent session validation
- Implemented `history_server/bar_aggregator.py` — 1m/5m/1h/1d OHLCV aggregator using Bid price (MT5-aligned); upsert flush on period rollover
- Implemented `core/tick_publisher.py` — fire-and-forget WebSocket publisher; bounded queue (10k ticks), drop-oldest overflow, exponential backoff reconnect; never blocks main_server
- Extended `access_server` — path-prefix routing so `/history/*` routes to port 8002
- Wrote and passed `tests/test_phase6.py`

---

### Phase 7 — Real Price Feed & LP/Gateway Bridge (MT5 Integration)
- Fixed `trade-server/main.py` — reads port from `PORT` env var (default 8003) to prevent conflict with main_server
- Created `history_server/Datafeeds/mt5_feed.py` — live MT5 feed client: authenticates with trade-server, subscribes to msgpack WebSocket ticks, applies 3-layer filtration (negative spread, extreme spread >500pts, price jump >5%), pushes valid ticks to `main_server`; controlled by `START_FEED` env var
- Created `history_server/Gateways/mt5_gateway.py` — A-book LP bridge: submits orders to trade-server `/place-order`; returns FILLED (with LP price) or REJECTED
- Updated `history_server/history_main.py` — starts MT5Feed on startup; exposes `POST /internal/gateway/execute`
- Updated `main_server/webapi/manager_api.py` — added `POST /internal/ticks`; bound all engine singletons to `app.state`
- Updated `matching/engine.py` — added `_quote_times` dict and `get_quote_age()` method
- Updated `core/trade_center.py` — stale quote gating (rejects market orders if quote >10s old); A-book execution via history server when `REAL_LP=true`; same deal/position write path for both A-book and B-book fills; zero B-book fallback on LP failure
- Updated `rms/engine.py` — pauses Stop Out checks for accounts holding positions in symbols with stale quotes
- Created `tests/test_phase7.py` — 4 regression tests covering all of the above
- **Final result: 29/29 tests passed**

---

## 4. Complete File Reference Table

### main_server

| File | Role |
|------|------|
| [`main.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/main.py) | Entry point — starts FastAPI app via uvicorn |
| [`webapi/manager_api.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/webapi/manager_api.py) | All HTTP routes: auth login, order submission, admin CRUD, internal tick ingest, internal auth validate, session management (Redis + memory fallback) |
| [`core/trade_center.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/core/trade_center.py) | OMS — validates, locks, routes, executes, and logs all orders; handles B-book matching and A-book LP execution; enforces stale quote gating |
| [`core/position_keeper.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/core/position_keeper.py) | In-memory position cache — creates, closes, nets positions; syncs with `positions` DB table |
| [`core/tick_center.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/core/tick_center.py) | Tick processor — SL/TP triggers, floating P&L update, margin recalculation, Stop Out checks, tick publishing to history_server |
| [`core/tick_publisher.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/core/tick_publisher.py) | Fire-and-forget history_server publisher — bounded queue (10k), drop-oldest overflow, exponential backoff reconnect; never blocks main_server |
| [`core/deal_writer.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/core/deal_writer.py) | Writes deal records atomically within an existing DB transaction |
| [`core/interfaces/i_oms.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/core/interfaces/i_oms.py) | Abstract interface for OMS |
| [`core/interfaces/i_rms.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/core/interfaces/i_rms.py) | Abstract interface for RMS |
| [`core/interfaces/i_matching.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/core/interfaces/i_matching.py) | Abstract interface for Matching Engine |
| [`core/interfaces/i_position_keeper.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/core/interfaces/i_position_keeper.py) | Abstract interface for Position Keeper |
| [`core/interfaces/i_event_bus.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/core/interfaces/i_event_bus.py) | Abstract interface for Event Bus |
| [`matching/engine.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/matching/engine.py) | Price book — stores Bid/Ask per symbol, matches orders against top-of-book, tracks quote timestamps, exposes `get_quote_age()` |
| [`rms/engine.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/rms/engine.py) | RMS — pre-trade margin check, post-fill account recalculation, Stop Out scanning; skips Stop Out for accounts with stale symbol positions |
| [`rms/accounting.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/rms/accounting.py) | Margin calculation helpers — reads group-symbol overrides from DB; uses Decimal math throughout |
| [`routing/engine.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/routing/engine.py) | Routing rules engine — evaluates orders by priority ASC; returns EXECUTE / TO_DEALER / TO_GATEWAY / REJECT; falls back to server default if no rules match |
| [`bases/connection.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/bases/connection.py) | Dual-mode DB adapter — PostgreSQL (asyncpg) in production, SQLite async wrapper for testing; unified pool interface |
| [`bases/schema.sql`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/bases/schema.sql) | PostgreSQL schema — accounts, groups, symbols, orders, positions, deals, routing_rules, group_symbols |
| [`bases/schema_sqlite.sql`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/bases/schema_sqlite.sql) | SQLite equivalent schema for developer testing |
| [`shared/schemas/v1.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/shared/schemas/v1.py) | Shared constants and Pydantic models — ORDER_STATE_*, ORDER_REASON_*, OrderRequest, OrderResponse |
| [`shared/event_bus.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/shared/event_bus.py) | In-process async pub/sub event bus |

### access_server

| File | Role |
|------|------|
| [`access_main.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/access_server/access_main.py) | Reverse proxy and auth gate — validates session tokens, rate-limits by IP, routes by path prefix (`/history/*` → port 8002, others → port 8000 by region), upgrades WebSocket connections |
| [`config/access.ini`](file:///C:/Users/DELL/Downloads/server3/broker_server/access_server/config/access.ini) | Region-to-server mapping — maps region names to `host:port` upstream addresses |

### history_server

| File | Role |
|------|------|
| [`history_main.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/history_server/history_main.py) | History server FastAPI app (port 8002) — tick ingest WebSocket, OHLCV history endpoint, internal LP execution route, starts MT5Feed worker on startup |
| [`bar_aggregator.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/history_server/bar_aggregator.py) | OHLCV bar aggregator — 1m/5m/1h/1d candles using Bid price; upsert flush on period rollover; timezone-aware period floor rounding |
| [`Datafeeds/mt5_feed.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/history_server/Datafeeds/mt5_feed.py) | MT5 live price feed — authenticates with trade-server, subscribes to msgpack WebSocket ticks, applies 3-layer filtration, pushes valid ticks to main_server |
| [`Gateways/mt5_gateway.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/history_server/Gateways/mt5_gateway.py) | A-book LP bridge — submits orders to trade-server `/place-order`; returns FILLED (with execution price) or REJECTED |

### trade-server (External)

| File | Role |
|------|------|
| [`main.py`](file:///C:/Users/DELL/Downloads/server3/trade-server/main.py) | MT5 connector — wraps python-MetaTrader5; exposes `POST /api/v1/connect`, `POST /api/v1/place-order`, `GET /ws/marketdata`; reads port from `PORT` env var |
| [`ws/stream.py`](file:///C:/Users/DELL/Downloads/server3/trade-server/ws/stream.py) | WebSocket broadcaster — manages tick subscribers and broadcasts live ticks as binary msgpack |

### Tests

| File | Phase | What It Tests |
|------|-------|---------------|
| [`tests/test_trade.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/tests/test_trade.py) | 2 | Basic order placement, position creation, close/net logic |
| [`tests/test_phase2_ticks.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/tests/test_phase2_ticks.py) | 2 | SL/TP tick triggers, pending order activation, floating P&L updates |
| [`tests/test_phase3.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/tests/test_phase3.py) | 3 | End-to-end auth flow, WebSocket proxy upgrade, defense-in-depth security |
| [`tests/test_bugs.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/tests/test_bugs.py) | 5 | Position close crash regression, no-quote rejection, concurrent order race netting |
| [`tests/test_margin.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/tests/test_margin.py) | 5 | Group-symbol margin override with Decimal math, pre-trade margin check accuracy |
| [`tests/test_phase4.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/tests/test_phase4.py) | 4 | Admin CRUD, group margin overrides, routing engine (EXECUTE/TO_DEALER/TO_GATEWAY/REJECT) |
| [`tests/test_phase6.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/tests/test_phase6.py) | 6 | History server decoupling (no blocking), queue overflow policy, bar aggregation, path-based proxy routing |
| [`tests/test_phase7.py`](file:///C:/Users/DELL/Downloads/server3/broker_server/main_server/tests/test_phase7.py) | 7 | Quote filtration, A-book execution (mocked LP), gateway failure isolation (zero B-book fallback), stale quote order rejection and Stop Out pause |

---

## 5. Test Suite Summary

| Test File | Tests | Result |
|-----------|-------|--------|
| `test_trade.py` | 1 | ✅ PASSED |
| `test_bugs.py` | 3 | ✅ PASSED |
| `test_margin.py` | 1 | ✅ PASSED |
| `test_phase2_ticks.py` | 6 | ✅ PASSED |
| `test_phase3.py` | 6 | ✅ PASSED |
| `test_phase4.py` | 4 | ✅ PASSED |
| `test_phase6.py` | 4 | ✅ PASSED |
| `test_phase7.py` | 4 | ✅ PASSED |
| **TOTAL** | **29** | **✅ 29/29 PASSED** |

---

## 6. Final Test Results

```
============================= test session starts ==============================
platform win32 -- Python 3.14.3, pytest-9.1.1, pluggy-1.6.0
rootdir: C:\Users\DELL\Downloads\server3\broker_server\main_server
collected 29 items

tests\test_bugs.py ...                                                   [ 10%]
tests\test_margin.py .                                                   [ 13%]
tests\test_phase2_ticks.py ......                                        [ 34%]
tests\test_phase3.py ......                                              [ 55%]
tests\test_phase4.py ....                                                [ 68%]
tests\test_phase6.py ....                                                [ 82%]
tests\test_phase7.py ....                                                [ 96%]
tests\test_trade.py .                                                    [100%]

================== 29 passed, 120 warnings in 253.63s (0:04:13) ===============
```

> ⚠️ All 120 warnings are Python 3.12+ deprecation notices (`datetime.utcnow()`, `on_event`, SQLite timestamp converter). Non-breaking. Can be cleaned up in a future maintenance phase.

---

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Per-account `asyncio.Lock` | Serializes concurrent orders for same account — prevents race conditions and duplicate position rows |
| Decimal math throughout | Eliminates float rounding bugs in margin and P&L |
| Dual-mode DB (PG + SQLite) | Full developer testing locally without a live PostgreSQL instance |
| Fire-and-forget tick publisher | Guarantees history_server going offline never blocks main_server execution |
| Quote age tracked in MatchingEngine | Central single source of truth for quote freshness, accessible to OMS, RMS, and tests |
| `REAL_LP` env var gate | Legacy tests use mock `PENDING_GATEWAY`; Phase 7 tests exercise real A-book execution — no code duplication |
| Same deal-write path for A-book and B-book | LP fills reuse identical deal + position transaction block — DRY and auditable |
| `START_FEED` env var | Disables live MT5 WebSocket during unit tests — keeps tests hermetic and fast |
