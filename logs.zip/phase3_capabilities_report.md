# Phase 3 System Capabilities Report: Standalone Access Server & Security Framework

This report details the implementation of Phase 3, reviewing the security architecture, session caching mechanics, resilience policies, and operational features now available on the platform.

---

## 1. Summary of What Has Been Done

We have built and verified a complete, highly-resilient standalone Access Server proxy and centralized authentication layer. The component structure and their interactions are shown in the architecture diagram below:

```mermaid
sequenceDiagram
    autonumber
    actor Client
    participant Access as Access Server Proxy (Port 8080)
    participant Redis as Centralized Redis (Port 6379)
    participant Main as Main Server (Port 8000)
    participant DB as SQL Database

    Client->>Access: Request (with Bearer Token / IP / WS)
    Access->>Access: Firewall & Rate-Limiter Checks (IP)
    
    rect rgb(20, 30, 40)
        Note over Access, Redis: Session Validation Path
        Access->>Redis: Check Session Cache (Fast path)
        alt Session Cache Hit
            Redis-->>Access: Return Login ID
        else Cache Miss / Redis Down
            Access->>Main: GET /internal/auth/validate (with X-Internal-Secret)
            Main->>Main: Verify X-Internal-Secret
            Main->>Main: Fetch & Validate Session
            Main-->>Access: Return Login ID
        end
    end

    Access->>Main: Proxy Request to Upstream Main Server
    Main->>Main: Verify token login matches resource ID (Defense-in-depth)
    Main->>DB: Fetch/Mutate Database
    Main-->>Access: HTTP Response
    Access-->>Client: Final Response
```

### Done: Standalone Access Server Proxy (`access_main.py`)
- Created an asynchronous FastAPI proxy routing HTTP and WebSocket connections upstream.
- Implemented **IP Firewall check** against configurable dynamic allow/deny lists.
- Implemented **IP & Account rate limiting** using a sliding-window algorithm backed by Redis with a local in-memory fallback.
- Added dynamic upstream mapping resolution supporting region-based upstreams.

### Done: Authentication & Defense-in-Depth Layer (`manager_api.py`)
- **OWASP-Compliant Hashing:** Implemented salted PBKDF2-HMAC-SHA256 with **600,000 iterations** (OWASP standard) and cryptographically secure 16-byte random salts (`secrets.token_bytes`).
- **Timing-Attack Protection:** Implemented `secrets.compare_digest` for secure password hash and validation comparison.
- **Secure Token Generation:** Tokens are produced using `secrets.token_hex(32)`, providing 256 bits of entropy from the OS CSPRNG.
- **Route Gating:** Gated `/internal/auth/validate` using a custom header (`X-Internal-Secret`) matched against a configurable environment secret to prevent public token-scanning attacks.
- **Defense in Depth:** Added FastAPI Dependency Injection checking that the request's token login matches the targeted resource (`request.login == current_login`).

### Done: High-Availability Session Manager
- **Dual-Write Hot Standby:** Session creation writes to both Redis and a local in-memory dictionary. If Redis goes down, logins persist without forcing immediate user logouts.
- **Resilient Circuit Breaker:** Implemented a non-blocking circuit breaker with a 10-second cooling-off period. If Redis goes down, fallback to memory is instantaneous, and the server automatically checks/reconnects after 10 seconds.
- **Immediate TTL Eviction:** Expired sessions are deleted from both Redis and the local dictionary on access.

---

## 2. Capabilities of the Current Implementation

The platform is now capable of supporting complex production environments, resolving previous single-point-of-failure limits:

### A. Scalable Multi-Region Deployment
Multiple standalone Access Server proxy instances can be placed at edge locations closer to clients (e.g., in different geographical regions) while sharing session states through Redis:

| Feature | Description | Status |
| :--- | :--- | :---: |
| **Geographic Proxies** | Client connects to the nearest Access Server proxy, lowering handshake latency. | **Operational** |
| **Global Session Store** | A user logging in via Main Server in Region A can have their session checked by Access Server in Region B instantly via Redis. | **Operational** |
| **Dynamic Routing** | Proxies map client requests to different main servers depending on client profile headers (e.g., routing to local DB mirrors). | **Operational** |

### B. High Resilience & Self-Healing
If the central Redis cache crashes or becomes unreachable, the system automatically adapts:

1. **Zero Downtime Fallback:** The circuit breaker trips in `0.5s` on connection failure. Calls bypass Redis and use the in-memory hot-standby copy instantly.
2. **Auto-Recovery:** As soon as the Redis cluster recovers, the next 10-second half-open check succeeds, resetting the failure timer and automatically restoring the shared cache database without server restarts.
3. **Graceful Teardowns:** Registered shutdown event handlers cleanly release all database connection pools and Redis sockets, preventing hanging ASGI threads.

### C. Hardened Security Boundary
We have established a secure edge boundary protecting core trading engines:

```
[Public Internet] 
       │ 
       ▼
┌─────────────────────────────────────────────────────────┐
│              STANDALONE ACCESS SERVER PROXY             │
│  - IP Allow/Deny Firewall Check                         │
│  - Sliding Window Rate-Limiting                         │
│  - JWT-like Bearer Token Validation                     │
└──────────────────────────┬──────────────────────────────┘
                           │ 
                [X-Internal-Secret Header]
                           │
                           ▼
┌─────────────────────────────────────────────────────────┐
│                    CORE MAIN SERVERS                    │
│  - /internal/auth/validate gated by shared key         │
│  - Login-ID verification on every endpoint               │
│  - Salted PBKDF2 Password Hashing (600,000 iterations)  │
└─────────────────────────────────────────────────────────┘
```

---

## 3. How to Start the Services Locally

You can launch the complete architecture on your local machine using the following commands:

1. **Start the Main Server (Internal Port 8000):**
   ```powershell
   cd broker_server/main_server
   python main.py
   ```
2. **Start the Access Server Edge Proxy (Public Port 8080):**
   ```powershell
   cd broker_server/access_server
   uvicorn access_main:app --port 8080
   ```
3. **Execute the Verification Suite:**
   To run all authentication, firewall, proxy, and websocket tests:
   ```powershell
   cd broker_server/main_server
   python -m pytest tests/test_phase3.py
   ```
