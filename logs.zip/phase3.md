# Phase 3 — Access Server (separate process) + Auth + Web API

## Scope note
This phase splits into **two separate deployables**, matching MT5's real design (`mt5access64.exe` is a distinct process from `mt5trade64.exe`):

- **`access_server/`** — thin reverse proxy. No trading logic, no direct DB access. Owns: TLS termination point, IP firewall, rate limiting, session-token validation (fast-path via Redis), region/upstream routing, request forwarding (HTTP + WebSocket) to `main_server`.
- **`main_server/`** — gains auth/session issuance and the client-facing Web API, but does **not** trust the network boundary alone — every account-scoped endpoint re-validates that the token's login matches the resource being accessed, even though `access_server` already checked. Defense in depth: if `access_server` is ever misconfigured, bypassed, or a second entry point is added later, `main_server` still can't be tricked into acting on the wrong account.

Redis is a new dependency this phase introduces — not present in the codebase yet. It's the shared session store both processes read/write.

## Authoritative references
- `MetaTrader5SDK/...` — no direct Access-Server API surface exists in the SDK (it's a proxy, not something plugins hook into), so use it only for the Web API contract (`10-api-contracts.md` §10.4) and return-code vocabulary.
- **MT5-Administrator docs** (just supplied): `Platform-Setup/Network-cluster.md`, `Platform-Setup/Security/Firewall.md`, `Platform-Setup/Security/Anti-DDoS-Protection.md` — these describe the real operational config surface (IP allow/deny, per-region components, DDoS provider integration) that `access_server`'s config should mirror the shape of, even in simplified form for now.
- `09-service-catalog.md` §2 (Access Proxy service detail) and `README.md` system map, for the original design intent.

## 1. `access_server/` — new process
- `config/access.ini` (or `.yaml`): a map of `region -> main_server upstream host:port`. Start with one region/one upstream — structure it so adding a second region later is a config change, not a code change.
- Middleware/pipeline per request, in order:
  1. **IP firewall** — allow/deny list from config (mirror `Firewall.md`'s allow/deny-by-IP model, simplified).
  2. **Rate limiting** — per-IP and per-account-login (once known), Redis-backed counters with a sliding or fixed window.
  3. **Session validation** — look up the bearer token in Redis. Missing/expired → reject immediately, never forward to `main_server`. This is the main reason for Redis being shared: `access_server` shouldn't need to call `main_server` just to reject a bad token.
  4. **Region routing** — resolve which upstream `main_server` to forward to (for now: single upstream, but implement the resolution step for real so it's not a stub to redo later).
  5. **Forward** — reverse-proxy the HTTP request (or WebSocket connection, for `/ws/stream/{account_id}`) to the resolved upstream, pass response back unmodified.
- No trading logic. No `asyncpg`/SQLite import here at all — if `access_server` ever needs to touch the trade DB directly, that's a design mistake, catch it in review.

## 2. `main_server` — auth + Web API additions
- `POST /web/auth/login` — body: `{login, password, server}` per `10-api-contracts.md` §10.4. Validate against `accounts.password_hash`. On success: generate a session token, write `session:{token} -> {login, expires_at}` to Redis, return `{token, account_id, expires_at}`.
- `POST /web/auth/logout` — delete the Redis session key.
- **Auth dependency** applied to every account-scoped endpoint (`/trade/order`, `/web/accounts/{id}/...`): extract token from `Authorization: Bearer`, re-check Redis (yes, even though `access_server` already did — this is the defense-in-depth check), and reject if the token's login doesn't match the `{id}`/`{login}` in the URL. This closes the current hole where anyone can place an order for any login.
- New read endpoints: `GET /web/accounts/{id}/positions`, `/orders`, `/history` — expose what `PositionKeeper`/`DealWriter` already track, per `10-api-contracts.md` §10.4.
- `WSS /ws/stream/{account_id}` — live tick + position/order push, sourced from the same event bus `TickCenter` already publishes to. `access_server` proxies the WS connection through; `main_server` still validates the token on WS upgrade, not just on the initial HTTP handshake.

## 3. What NOT to do this phase
- Don't build GeoIP-based region detection yet — explicit region param (header or query) is enough to prove the routing structure works. Real geo-routing is a config/ops concern for later, not a code change once the structure above exists.
- Don't implement the Anti-DDoS provider integration for real — just leave the config shape ready for it (matches `Anti-DDoS-Protection.md`'s "integration with external protection providers" pattern), actual provider hookup is deferred.
- Don't move trading logic into `access_server` for any reason, even convenience — if a future feature seems to need that, flag it for discussion rather than doing it inline.

## Regression tests required
- `access_server` rejects a request with no/expired token before it ever reaches `main_server` (assert `main_server` mock/stub was never called).
- `access_server` rate-limits after N requests in a window (per-IP and per-login).
- A valid, authenticated request is correctly proxied end-to-end (HTTP) and returns the same response `main_server` would give directly.
- WebSocket proxy test: a client connects through `access_server` to `/ws/stream/{account_id}` and receives a tick pushed by `main_server`.
- **Defense-in-depth test:** call `main_server` directly (bypassing `access_server` entirely, as if the network boundary were misconfigured) with a token whose login doesn't match the requested account — must still be rejected by `main_server`'s own check.
- Region routing test: two configured upstreams (one real, one a dummy/mock), requests tagged for each region land on the correct one.

## Report back
Same format as before — text changelog per file, test output, and explicitly call out: (a) whether Redis is now a hard runtime dependency for both processes or has a fallback, and (b) how `access_server` and `main_server` are meant to be started together in dev (two processes, one command? separate?) — I'll want that before suggesting anything about deployment.