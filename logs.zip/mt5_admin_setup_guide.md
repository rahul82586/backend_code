# MetaTrader 5 Broker Platform Scratch Setup Guide

This guide details the complete step-by-step platform configuration workflow that a MetaTrader 5 Administrator follows when building a broker environment from scratch.

```mermaid
graph TD
    A["1. Server Cluster Installation"] --> B["2. Global Platform Settings"]
    B --> C["3. Symbol Specifications setup"]
    C --> D["4. Data Feeds integration"]
    D --> E["5. LP Gateways & routing Rules"]
    E --> F["6. Client Groups creation"]
    F --> G["7. Manager Roles provisioning"]
    G --> H["8. Client accounts & onboarding"]
```

---

## Phase 1: Network Cluster & Infrastructure Setup

The foundational phase establishes the hardware roles and network connectivity.

### 1. Server Role Allocations
1. **Trade Server**: The central execution node. It manages the transaction databases, executes orders, maintains client accounts, and handles live trading sessions.
2. **History Server**: Manages price history archives (1-minute bars and ticks) and runs data feed integration drivers.
3. **Access Servers**: User-facing entry points. Clients connect here; Access Servers filter traffic, shield the Trade Server from DDoS, and cache current quotes.
4. **Backup Server**: Standby node that replicates databases from the Trade Server in real-time for hot-failover protection.

### 2. Encryption and Security
- Deploy 1024-bit/2048-bit RSA keys and SSL certificates for server-to-server and server-to-terminal traffic.
- Configure hardware firewalls permitting internal traffic between servers on ports (e.g. `8000`-`8004`) while keeping the primary Trade Server isolated from direct public IP bindings.

---

## Phase 2: Core Platform Settings & Symbol Specifications

Once the cluster is online, the administrator configures the financial instruments.

### 1. Global Parameters
- **Time Zones**: Establish platform time (usually GMT+2 or GMT+3 to align with New York market close).
- **Holidays Calendar**: Import trading holiday templates to disable order entries during global exchange closures.

### 2. Creating Symbol Hierarchies
Establish folder structures under the Symbols section (e.g. `Forex\`, `CFD\`, `Indices\`, `Crypto\`) to organize assets.

### 3. Specifications Properties Setup
For every financial instrument, configure:
- **Digits & Points**: Number of decimal places (e.g. `5` for EURUSD, `3` for USDJPY).
- **Contract Size**: Define standard lots (e.g., `100000` for Forex, `1` for Crypto, `100` for Gold).
- **Trade Calculation Mode**: Matches calculation behavior to asset type (e.g., *Forex*, *CFD*, *CFD-Leverage*, *Futures*, *Exchange Stocks*, *Options*).
- **Volume Constraints**: Volume Minimum, Volume Maximum, and Volume Step (e.g., Min: `0.01` lots, Max: `100` lots, Step: `0.01`).
- **Swaps (Rollovers)**: Set points/percentages, Friday/Wednesday triple-days, and custom holiday swap rules.
- **Trading & Quotes Sessions**: Set exact daily operating timetables for bidding (Quotes Session) and placing orders (Trades Session) for each day of the week.

---

## Phase 3: Data Feeds Integration (Price Feeders)

Before launching the market, prices must flow reliably.

### 1. Configuration of Feeder Modules
- Add turnkey data feed configurations (such as Dow Jones, LMAX, Bloomberg) or bind custom external data source APIs using the MT5 Gateway API.
- Data feeds run as separate executable files (`*.exe`) in the History Server's `/Datafeed/` directory, updating the History Server via `MT5APIGateway.dll`.

### 2. Data Feed Switching & Priority
- Position feeders sequentially in the Data Feeds list. Position defines priority: the server actively streams quotes from the top-priority feeder.
- If the primary data feed drops, the server triggers a timeout and switches automatically to the next available feeder in list sequence.
- Quotes from a **Gateway** (Liquidity Provider) take precedence over general **Data Feeds** to guarantee execution prices align with matching bids.

---

## Phase 4: Gateways & Liquidity Routing Setup

A-Book brokers require external execution gateways.

### 1. LP Gateways Setup
- Configure LP Gateways (e.g. Integral, PrimeXM, OneZero, LMAX) connecting the platform via FIX protocols to external ECNs or liquidity pools.
- Gateway configuration maps remote symbol names to local symbol names (e.g. translating remote `EURUSD.pro` to local `EURUSD`).

### 2. Setup of Routing Rules
Routing rules process client trade requests sequentially from top to bottom.
- **Action Types**: Configure rule behavior, such as `Process to dealers`, `Reject`, `Delay`, or `Send to ECN Matching`.
- **Conditions**: Match rule triggers by:
  - Account client groups (e.g. routing `real\retail\*` trades to Gateway A).
  - Symbol patterns/suffixes (e.g. matching `*.pro` to a raw ECN dealer).
  - Request type (e.g. routing Instant Execution to a dealer queue).
  - Volumetric bounds (routing trades above 10 lots to deep liquidity LPs).

---

## Phase 5: Client Groups & Risk Profiling

Groups represent client-tier trading accounts configurations.

### 1. Group Structural Parameters
Create client paths (e.g. `demo\standard`, `real\VIP`, `real\retail\EUR`) and define:
- **Maximum Leverage**: Set boundaries (e.g., `1:100` to `1:500`) and configure dynamic leverage scaling tables (reducing leverage as volume/exposure increases).
- **Margin Call & Stop Out**: Set thresholds (e.g., Margin Call at `100%`, Stop Out at `50%`) to manage account liquidation.

### 2. Symbol Overrides Availability
- Select which symbol paths are active for the group.
- Configure group spread markups (widening the default spreads to earn broker margins) and per-lot/percentage commission structures.

---

## Phase 6: Managers, Accounts & Onboarding

The final phase opens the doors to client onboarding and operations.

### 1. Manager Roles & Permissions
- Provision manager logins and assign specific permission boundaries:
  - **Dealer**: Permission to handle trade execution requests.
  - **Account Manager**: Permission to create and update client profiles.
  - **Risk Manager**: Permission to view open exposures, swap values, and margins.

### 2. Client Accounts Onboarding
- Register client data and create trading accounts.
- Assign the accounts to their respective Client Groups.
- Process initial financial deposits (updating client balances via the Manager API or Admin panel).

Once complete, client terminals can successfully connect, receive quotes, and execute live trades.
