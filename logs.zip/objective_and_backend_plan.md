# 🎯 Project Objective & Backend Testing Plan

## 1. Core Project Objective
The primary objective of this project is to implement a complete, mock **MetaTrader 5 (MT5) Broker Environment** comprising:
1. **Trade Servers (`broker_server`)**: Handles order management (OMS), risk management (RMS), routing policies (SOR), tick matching engines, position netting/hedging keepers, and historical chart aggregators.
2. **Administrative Console / Frontend (`my-app` / `@theia/mt5-admin`)**: A specialized, developer-oriented administrative interface built on **Eclipse Theia** to manage server configurations (Symbols, Groups, Feeds, Gateway translation mapping, Accounts).
3. **Feed Ingestion Service (`trade-server`)**: Emulates live liquidity provider (LP) web-socket feeds, broadcasts prices, and processes A-book orders.

This sandbox allows the simulation, evaluation, and end-to-end automated testing of custom backend broker operations, routing behaviors (A-Book vs. B-Book vs. Dealer desk confirmation), and risk/liquidation workflows.

---

## 2. Subsystem Breakdown & Testing Protocols

### 2.1 Order Management System (OMS)
* **Goal**: Receive market and pending orders (Buy/Sell, Limit, Stop), serialize client operations using async locks to prevent race conditions (e.g. double spending/over-allocation of margin), manage order state lifecycle transitions, and record finished transactions in the `deals` database.
* **Testing Protocol**:
  - Run asynchronous Python scripts issuing concurrent orders for the same account.
  - Verify that orders transition cleanly through `STARTED` ➔ `FILLED` or `REJECTED`.
  - Assert that all successful trades create a corresponding row in the `deals` database with matched execution prices.

### 2.2 Matching Engine & B-Book Execution
* **Goal**: Provide in-memory top-of-book matching against live quotes. Perform immediate execution of B-book orders at the current internal Bid/Ask price, accounting for custom markups and spread offsets. Reject orders if incoming quotes are stale (>10 seconds).
* **Testing Protocol**:
  - Feed mock ticks to the feeder web-socket with variable timestamps.
  - Submit market orders immediately after and confirm they fill at the exact quote Bid/Ask.
  - Sleep for 11 seconds to invalidate the quote age and submit an order; assert the order is rejected for stale price quote age.

### 2.3 Risk Management System (RMS)
* **Goal**: Perform pre-trade margin checks against free margin (calculated from account balance, leverage, and open position floating P&L). Monitor active positions on every tick to trigger margin calls and automatically liquidate (Stop Out) accounts if margin level falls below defined thresholds.
* **Testing Protocol**:
  - Create account records with low balance and high leverage.
  - Open a large contract size position to lock up maximum margin.
  - Send hostile tick updates to push the position into large negative floating P&L.
  - Verify that the Tick Center detects the Stop Out breach and triggers the liquidation sequence, transitioning positions to closed and writing deal records.

### 2.4 Smart Order Router (SOR) & Routing Rules
* **Goal**: Evaluate client orders against a prioritized rules table (matching symbol folders, account group prefixes, order volume ranges, and type constraints) to decide the execution action:
  - `EXECUTE` (B-book match locally).
  - `TO_GATEWAY` (A-book route to LP).
  - `TO_DEALER` (Queue for manual confirmation).
  - `REJECT` (Immediate rejection).
* **Testing Protocol**:
  - Setup routing rules table with wildcards (e.g., `forex*` ➔ `EXECUTE`, `!forex\Exotics*` ➔ `REJECT`).
  - Submit orders for different symbol paths and assert the routing engine assigns the correct target action.

### 2.5 Group-Symbol Translation (Bridge / Mapping)
* **Goal**: Match broker symbol naming structures (e.g., folder paths like `forex\EUTUSD` or base symbols like `EUTUSD`) against custom translation rules and map them to their corresponding Liquidity Provider symbols (e.g., `EURUSD`).
* **Testing Protocol**:
  - Define platform-to-source mappings: `Platform Symbol = EUTUSD` ➔ `Source Symbol = EURUSD`.
  - Feed LP ticks for `EURUSD` and assert that the history server translates and broadcasts them to subscribers as `EUTUSD`.
  - Place a trade on `EUTUSD` and assert the gateway maps it correctly to the LP's execution system.

---

## 3. Reference Test Cases

### 3.1 Automated Scenarios: `test_feeder_scenarios.py`
This script implements comprehensive tests for tick filtration, translation mappings, wildcard matching, and routing rules:
- **Test 1**: Direct string parsing logic validation for folder wildcards (`forex\*` vs `!forex\Exotics\*`).
- **Test 2**: Base-name symbol matching during translation mapping lookup (resolving short codes like `EUTUSD` to `EURUSD`).
- **Test 3**: Margin override lookup validations.

### 3.2 Frontend Logic Simulations: `test_frontend_logic.py`
Simulates the React UI actions in a terminal context, checking string manipulation filters when selecting items from folder trees to prevent duplicate entries and maintain clean comma-delimited configuration rules.



---
# STEPS TO FOLOW TO GET STARTED

Your flow is basically right — here's the actual MT5 order, tightened up, with the couple of things people usually get backwards or forget:

**1. Server-wide Symbols first, not Groups first.**
In real MT5, you create the **Symbol** (EURUSD, XAUUSD etc.) at the server level before groups even matter — digits, contract size, calculation mode (Forex vs CFD), swap, etc. Symbols exist independently of any group.

**2. Then Groups.**
Groups (`demo`, `real\A-book`, `real\B-book` etc.) are permission + risk templates, not accounts themselves. In a group you set: leverage, margin call %, stop-out %, default spread markup — and critically, **which symbols this group is even allowed to see/trade** (this is your "group symbols" step, correct). A symbol existing server-wide doesn't mean every group can trade it — you explicitly enable it per group, and can override margin/spread per symbol per group there too.

**3. Gateways & Data Feed.**
This is separate from groups/symbols — it's *where prices come from* and *where A-book flow goes*. You configure the LP/feed connection once, then symbols subscribe to it for pricing. This is infrastructure, not client-facing config.

**4. Routing Rules — this is the piece your description skipped.**
This is the actual A/B-book decision layer, and it sits *between* order placement and execution — not something you decide manually per trade. You define rules: "orders from group `real\B-book`, symbol `EURUSD`, volume < 1 lot → B-book (internal)" or "→ A-book (send to gateway)". So the A/B split isn't really "which group did you put them in" alone — group often just labels risk category, and routing rules are what actually send the order to internal book vs LP. Real desks also route dynamically off volume/exposure, not just group name.

**5. Only now — Accounts.**
Correct — account creation just means: pick a login, assign a **group** (which silently hands the account all that group's leverage/margin/symbol-visibility/spread rules), set starting balance. The account itself carries almost no logic — the group does.

**6. Client trades → order hits Routing → EXECUTE (B-book) / TO_GATEWAY (A-book) / TO_DEALER (manual desk confirm) / REJECT.**
Correct, this is your last step. One nuance: real desks don't statically decide "this account is always A-book" — routing rules can re-evaluate per order (by volume, symbol, even time of day), so the same account can be B-booked on small trades and A-booked past a size threshold. Worth deciding if you want that flexibility or a simpler "account is A-book or B-book, full stop" model — both are valid, just a decision to make consciously.

So the one correction to your mental model: **routing rules, not group assignment alone, are the actual A/B-book switch.** Group assignment sets risk parameters and symbol visibility; routing rules decide where the order physically goes.

```mermaid
flowchart TD
    A[1. Create Symbols<br/>server-wide: EURUSD, XAUUSD, digits, contract size, calc mode] --> B[2. Create Groups<br/>demo / real-A-book / real-B-book<br/>leverage, margin call %, stop-out %, default spread]
    B --> C[3. Enable Symbols per Group<br/>choose which symbols this group can see/trade<br/>+ per-group margin/spread override]
    A --> D[4. Configure Gateways and Data Feed<br/>LP connection, price source]
    D --> C
    C --> E[5. Create Client Account<br/>assign login to a Group<br/>account inherits group's leverage/margin/symbols/spread]
    E --> F[6. Client places Order]
    F --> G[7. Routing Rules Engine<br/>matches: group, symbol, order type, volume]
    G --> H[EXECUTE<br/>B-book internal fill]
    G --> I[TO_GATEWAY<br/>A-book: send to LP]
    G --> J[TO_DEALER<br/>manual desk confirm/reject]
    G --> K[REJECT]
    H --> L[RMS: margin check, P&L, margin call, stop-out]
    I --> L
    J --> L
```